import { X, Activity, Atom, Gauge, Thermometer, Clock3 } from "lucide-react";
import type { CosmologyState } from "../physics/cosmology";
import { formatScientific } from "../physics/cosmology";

interface ScienceModalProps {
  open: boolean;
  onClose: () => void;
  state: CosmologyState;
}

function Metric({
  icon: Icon,
  label,
  value,
  unit,
}: {
  icon: typeof Activity;
  label: string;
  value: string;
  unit: string;
}) {
  return (
    <div className="metric-card">
      <div className="metric-label"><Icon size={15} /> {label}</div>
      <strong>{value}</strong>
      <span>{unit}</span>
    </div>
  );
}

export function ScienceModal({ open, onClose, state }: ScienceModalProps) {
  if (!open) return null;

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
      <section
        className="science-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="science-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <header className="modal-header">
          <div>
            <span className="eyebrow">UNIVERSUM / LABORATÓRIO</span>
            <h2 id="science-title">Painel científico</h2>
            <p>Valores derivados do modelo cosmológico simplificado em execução.</p>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="Fechar painel">
            <X size={20} />
          </button>
        </header>

        <div className="metric-grid">
          <Metric icon={Clock3} label="TEMPO SIMULADO" value={formatScientific(state.timeSeconds)} unit="segundos" />
          <Metric icon={Activity} label="FATOR DE ESCALA RELATIVO" value={state.scaleFactor.toFixed(3)} unit="a / a₀" />
          <Metric icon={Thermometer} label="TEMPERATURA ESTIMADA" value={formatScientific(state.temperatureKelvin)} unit="kelvin · referência didática" />
          <Metric icon={Gauge} label="PARÂMETRO DE HUBBLE" value={formatScientific(state.hubblePerSecond)} unit="s⁻¹" />
        </div>

        <div className="equation-panel">
          <div className="section-heading"><Atom size={16} /> MODELO UTILIZADO</div>
          <div className="equation">a(t) / a₀ = √(t / t₀)</div>
          <div className="equation">T(t) / T₀ = a₀ / a(t)</div>
          <div className="equation">H(t) = 1 / (2t)</div>
          <p>
            Aproximação para uma fase dominada por radiação. A temperatura usa
            uma normalização didática de 10¹³ K em t₀ = 10⁻⁶ s. O painel calcula
            a evolução dessas grandezas; a transição quark-hádron exibida na
            narrativa ainda é uma explicação física, não um cálculo de QCD.
          </p>
        </div>

        <div className="modal-footnote">
          <span className="status-dot" />
          Cálculos atualizados continuamente conforme a rolagem da experiência.
        </div>
      </section>
    </div>
  );
}
