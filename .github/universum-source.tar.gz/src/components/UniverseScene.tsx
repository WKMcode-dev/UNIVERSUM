import { useMemo, useRef } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Stars } from "@react-three/drei";
import * as THREE from "three";

interface ParticleFieldProps {
  progress: number;
}

function seeded(index: number, salt: number) {
  const value = Math.sin(index * 127.1 + salt * 311.7) * 43758.5453;
  return value - Math.floor(value);
}

const PARTICLE_COUNT = 1800;
const CLUSTER_COUNT = 9;

function ParticleField({ progress }: ParticleFieldProps) {
  const pointsRef = useRef<THREE.Points>(null);
  const { positions, colors, clusterCenters, clusterIds, localOffsets, hotColors, coolColors } = useMemo(() => {
    const positions = new Float32Array(PARTICLE_COUNT * 3);
    const colors = new Float32Array(PARTICLE_COUNT * 3);
    const origins = new Float32Array(PARTICLE_COUNT * 3);
    const clusterCenters = new Float32Array(CLUSTER_COUNT * 3);
    const clusterIds = new Uint8Array(PARTICLE_COUNT);
    const localOffsets = new Float32Array(PARTICLE_COUNT * 3);
    const hotColors = new Float32Array(PARTICLE_COUNT * 3);
    const coolColors = new Float32Array(PARTICLE_COUNT * 3);

    // Nove regiões de referência distribuídas no volume. Elas servem
    // apenas para organizar a contração visual dos grupos na cena.
    for (let cluster = 0; cluster < CLUSTER_COUNT; cluster++) {
      const y = 1 - (cluster / (CLUSTER_COUNT - 1)) * 2;
      const radius = Math.sqrt(1 - y * y);
      const angle = cluster * Math.PI * (3 - Math.sqrt(5));
      clusterCenters[cluster * 3] = Math.cos(angle) * radius * 0.48;
      clusterCenters[cluster * 3 + 1] = y * 0.48;
      clusterCenters[cluster * 3 + 2] = Math.sin(angle) * radius * 0.48;
    }

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const theta = seeded(i, 1) * Math.PI * 2;
      const z = seeded(i, 2) * 2 - 1;
      const radius = Math.cbrt(seeded(i, 3)) * 0.78;
      const ring = Math.sqrt(1 - z * z);
      origins[i * 3] = Math.cos(theta) * ring * radius;
      origins[i * 3 + 1] = z * radius;
      origins[i * 3 + 2] = Math.sin(theta) * ring * radius;

      let nearestCluster = 0;
      let nearestDistance = Number.POSITIVE_INFINITY;
      for (let cluster = 0; cluster < CLUSTER_COUNT; cluster++) {
        const dx = origins[i * 3] - clusterCenters[cluster * 3];
        const dy = origins[i * 3 + 1] - clusterCenters[cluster * 3 + 1];
        const dz = origins[i * 3 + 2] - clusterCenters[cluster * 3 + 2];
        const distance = dx * dx + dy * dy + dz * dz;
        if (distance < nearestDistance) {
          nearestDistance = distance;
          nearestCluster = cluster;
        }
      }
      clusterIds[i] = nearestCluster;

      hotColors[i * 3] = 1.0;
      hotColors[i * 3 + 1] = 0.34 + seeded(i, 4) * 0.2;
      hotColors[i * 3 + 2] = 0.12 + seeded(i, 5) * 0.12;
      coolColors[i * 3] = 0.28 + seeded(i, 6) * 0.16;
      coolColors[i * 3 + 1] = 0.68 + seeded(i, 7) * 0.18;
      coolColors[i * 3 + 2] = 0.95;
    }

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const cluster = clusterIds[i];
      localOffsets[i * 3] = origins[i * 3] - clusterCenters[cluster * 3];
      localOffsets[i * 3 + 1] = origins[i * 3 + 1] - clusterCenters[cluster * 3 + 1];
      localOffsets[i * 3 + 2] = origins[i * 3 + 2] - clusterCenters[cluster * 3 + 2];
    }

    return { positions, colors, clusterCenters, clusterIds, localOffsets, hotColors, coolColors };
  }, []);

  useFrame(({ clock }, delta) => {
    if (!pointsRef.current) return;
    const geometry = pointsRef.current.geometry;
    const positionAttribute = geometry.attributes.position as THREE.BufferAttribute;
    const colorAttribute = geometry.attributes.color as THREE.BufferAttribute;

    // A expansão é contínua. A hadronização visual começa perto da
    // temperatura de crossover da QCD, e não no início da rolagem.
    const expansion = THREE.MathUtils.smoothstep(progress, 0.02, 0.74);
    const cooling = THREE.MathUtils.smoothstep(progress, 0.02, 0.74);
    const hadronization = THREE.MathUtils.smoothstep(progress, 0.73, 0.91);
    const expansionScale = 1 + expansion * 4.6;
    const breathing = 1 + Math.sin(clock.elapsedTime * 0.7) * 0.006;

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const cluster = clusterIds[i];
      const centerX = clusterCenters[cluster * 3] * expansionScale;
      const centerY = clusterCenters[cluster * 3 + 1] * expansionScale;
      const centerZ = clusterCenters[cluster * 3 + 2] * expansionScale;
      const localScale = THREE.MathUtils.lerp(1, 0.13, hadronization);

      positionAttribute.setXYZ(
        i,
        (centerX + localOffsets[i * 3] * expansionScale * localScale) * breathing,
        (centerY + localOffsets[i * 3 + 1] * expansionScale * localScale) * breathing,
        (centerZ + localOffsets[i * 3 + 2] * expansionScale * localScale) * breathing,
      );

      colorAttribute.setXYZ(
        i,
        THREE.MathUtils.lerp(hotColors[i * 3], coolColors[i * 3], cooling),
        THREE.MathUtils.lerp(hotColors[i * 3 + 1], coolColors[i * 3 + 1], cooling),
        THREE.MathUtils.lerp(hotColors[i * 3 + 2], coolColors[i * 3 + 2], cooling),
      );

    }

    positionAttribute.needsUpdate = true;
    colorAttribute.needsUpdate = true;
    pointsRef.current.rotation.y += delta * 0.012;
    pointsRef.current.rotation.x = Math.sin(clock.elapsedTime * 0.12) * 0.018;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.024} vertexColors transparent opacity={0.92} sizeAttenuation depthWrite={false} />
    </points>
  );
}

function PrimordialCore({ progress }: ParticleFieldProps) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, delta) => {
    if (!ref.current) return;
    const expansion = THREE.MathUtils.smoothstep(progress, 0.02, 0.74);
    const material = ref.current.material as THREE.MeshBasicMaterial;
    ref.current.scale.setScalar(0.42 + (1 - expansion) * 0.48);
    material.opacity = 0.2 * (1 - THREE.MathUtils.smoothstep(progress, 0.12, 0.62));
    ref.current.rotation.y += delta * 0.08;
  });

  return (
    <mesh ref={ref}>
      <icosahedronGeometry args={[1, 2]} />
      <meshBasicMaterial color="#ff9a64" wireframe transparent opacity={0.2} />
    </mesh>
  );
}

function SceneContent({ progress }: ParticleFieldProps) {
  const group = useRef<THREE.Group>(null);
  const { camera } = useThree();

  useFrame(() => {
    const expansion = THREE.MathUtils.smoothstep(progress, 0.02, 0.74);
    camera.position.z = THREE.MathUtils.lerp(7.6, 12.2, expansion);
    camera.position.x = THREE.MathUtils.lerp(0, 0.22, expansion);
    camera.lookAt(0, 0, 0);
    if (group.current) {
      group.current.rotation.y = THREE.MathUtils.lerp(0, 0.08, expansion);
    }
  });

  return (
    <group ref={group}>
      <ambientLight intensity={0.75} />
      <pointLight position={[0, 0, 3]} intensity={1.6} color="#ffad78" />
      <pointLight position={[-4, 2, -3]} intensity={1.1} color="#5caee8" />
      <PrimordialCore progress={progress} />
      <ParticleField progress={progress} />
    </group>
  );
}

export function UniverseScene({ progress }: ParticleFieldProps) {
  return (
    <div className="scene-canvas" aria-label="Visualização tridimensional da evolução do Universo">
      <Canvas camera={{ position: [0, 0, 7.6], fov: 45 }} dpr={[1, 1.5]} gl={{ antialias: true, alpha: true }}>
        <color attach="background" args={["#05080e"]} />
        <fog attach="fog" args={["#05080e", 9, 22]} />
        <Stars radius={70} depth={45} count={1500} factor={2} saturation={0.2} fade speed={0.08} />
        <SceneContent progress={progress} />
      </Canvas>
      <div className="scene-vignette" />
      <div className="scene-coordinate">CAMPO DE VISUALIZAÇÃO · 3D</div>
    </div>
  );
}
