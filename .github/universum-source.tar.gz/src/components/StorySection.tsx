import type { Chapter } from "../data/chapters";

interface StorySectionProps {
  chapter: Chapter;
  active: boolean;
}

export function StorySection({ chapter, active }: StorySectionProps) {
  return (
    <section className={`story-section ${active ? "is-active" : ""}`} data-chapter={chapter.id}>
      <div className="story-copy">
        <span className="story-number">{chapter.number} / 03</span>
        <span className="eyebrow">{chapter.eyebrow}</span>
        <h2>{chapter.title}</h2>
        <p className="story-description">{chapter.description}</p>
        <p className="story-detail">{chapter.detail}</p>
        <div className="story-rule"><span /></div>
      </div>
    </section>
  );
}
