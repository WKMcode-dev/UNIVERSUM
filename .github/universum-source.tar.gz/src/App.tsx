import { useEffect, useMemo, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowDown, FlaskConical, MoveUpRight } from "lucide-react";
import { UniverseScene } from "./components/UniverseScene";
import { StorySection } from "./components/StorySection";
import { ScienceModal } from "./components/ScienceModal";
import { chapters } from "./data/chapters";
import { calculateCosmology, getPhase } from "./physics/cosmology";

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const storyColumnRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);
  const [activeChapter, setActiveChapter] = useState(0);
  const [modalOpen, setModalOpen] = useState(false);

  const physics = useMemo(() => calculateCosmology(progress), [progress]);
  const phase = getPhase(progress);

  useEffect(() => {
    const storyColumn = storyColumnRef.current;
    if (!storyColumn) return;

    const syncTimeline = (progressValue: number) => {
      const nextProgress = Math.min(1, Math.max(0, progressValue));
      setProgress(nextProgress);
      // Os limites correspondem aos pontos em que cada capítulo entra
      // no campo de leitura: 0–25%, 25–75% e 75–100%.
      setActiveChapter(nextProgress < 0.25 ? 0 : nextProgress < 0.75 ? 1 : 2);
    };

    const timeline = ScrollTrigger.create({
      trigger: storyColumn,
      start: "top top",
      end: "bottom bottom",
      onUpdate: (self) => syncTimeline(self.progress),
      onRefresh: (self) => syncTimeline(self.progress),
    });

    syncTimeline(timeline.progress);
    return () => timeline.kill();
  }, []);

  useEffect(() => {
    if (!modalOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setModalOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [modalOpen]);

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Universum início">
          <span className="brand-mark">U</span>
          <span>UNIVERSUM<span className="brand-dot">.</span></span>
        </a>
        <div className="topbar-right">
          <span className="topbar-status"><i /> EXPERIÊNCIA INTERATIVA</span>
          <button className="lab-button" onClick={() => setModalOpen(true)}>
            <FlaskConical size={16} />
            <span>Laboratório</span>
            <MoveUpRight size={14} />
          </button>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="hero-orbit hero-orbit-one" />
        <div className="hero-orbit hero-orbit-two" />
        <div className="hero-content">
          <span className="eyebrow hero-eyebrow">COSMOLOGIA · EVOLUÇÃO DO UNIVERSO</span>
          <h1>Do estado<br /><em>primordial.</em></h1>
          <p>
            O Universo observável evoluiu a partir de um estado inicial
            extremamente quente e denso. Ao longo do tempo, sua expansão
            alterou a temperatura, a densidade e as condições para a formação
            de partículas, núcleos, átomos e estruturas cósmicas.
          </p>
          <a className="scroll-cue" href="#experience">
            <span>VER A SEQUÊNCIA FÍSICA</span>
            <ArrowDown size={15} />
          </a>
        </div>
        <div className="hero-index">COSMOLOGIA / 001</div>
      </section>

      <section className="experience" id="experience">
        <div className="scene-sticky">
          <UniverseScene progress={progress} />
          <div className="scene-overlay-top">
            <span className="eyebrow">EVOLUÇÃO COSMOLÓGICA</span>
            <span className="scene-phase">{phase.index} — {phase.title}</span>
          </div>
          <div className="scene-overlay-bottom">
            <div className="progress-track"><span style={{ transform: `scaleX(${progress})` }} /></div>
            <div className="scene-readout">
              <span>TEMPO <b>{physics.timeSeconds.toExponential(2)} s</b></span>
              <span>ESCALA <b>{physics.scaleFactor.toFixed(2)}×</b></span>
              <span>TEMP. <b>{physics.temperatureKelvin.toExponential(2)} K</b></span>
            </div>
          </div>
        </div>

        <div className="story-column" ref={storyColumnRef}>
          {chapters.map((chapter, index) => (
            <StorySection key={chapter.id} chapter={chapter} active={activeChapter === index} />
          ))}
          <section className="story-end">
            <span className="eyebrow">SÍNTESE DO TRECHO</span>
            <h2>As condições mudam. Os processos também.</h2>
            <p>
              A expansão reduz a temperatura e a densidade do Universo.
              Essa mudança não cria partículas por uma simples sequência
              mecânica: ela altera quais estados e interações são fisicamente
              possíveis. Neste trecho, acompanhamos um modelo simplificado
              da expansão durante uma fase dominada por radiação e uma
              representação conceitual da formação de hádrons.
            </p>
            <p>
              A etapa seguinte do projeto deverá tratar a transição
              quark-hádron com parâmetros termodinâmicos documentados,
              antes de avançar para a nucleossíntese primordial.
            </p>
            <button className="text-button" onClick={() => setModalOpen(true)}>
              Consultar grandezas e equações <MoveUpRight size={15} />
            </button>
          </section>
        </div>
      </section>

      <footer className="footer">
        <span>UNIVERSUM<span className="brand-dot">.</span></span>
        <span>MODELO DIDÁTICO · NÃO É UMA RECONSTRUÇÃO COMPLETA DO UNIVERSO PRIMORDIAL</span>
      </footer>

      <button className="floating-lab" onClick={() => setModalOpen(true)} aria-label="Abrir laboratório científico">
        <FlaskConical size={19} />
        <span>LABORATÓRIO</span>
      </button>

      <ScienceModal open={modalOpen} onClose={() => setModalOpen(false)} state={physics} />
    </main>
  );
}
