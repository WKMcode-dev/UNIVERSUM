export interface Chapter {
  id: string;
  number: string;
  eyebrow: string;
  title: string;
  description: string;
  detail: string;
  progress: number;
}

export const chapters: Chapter[] = [
  {
    id: "primordial",
    number: "01",
    eyebrow: "CONDIÇÃO FÍSICA · UNIVERSO JOVEM",
    title: "Um plasma extremamente quente.",
    description:
      "No intervalo representado por esta simulação, o Universo era composto por um meio muito quente e denso. A energia térmica era suficiente para manter a matéria em estados nos quais partículas interagiam continuamente. Não havia átomos: as condições eram incompatíveis com a existência de estruturas atômicas estáveis.",
    detail:
      "O modelo começa em t₀ = 10⁻⁶ segundo. Esse instante é um recorte de uma fase inicial conhecida por modelos cosmológicos; não corresponde ao instante da origem absoluta nem descreve o que teria ocorrido antes dele.",
    progress: 0.00,
  },
  {
    id: "expansion",
    number: "02",
    eyebrow: "PROCESSO · EXPANSÃO E RESFRIAMENTO",
    title: "A expansão altera as condições físicas.",
    description:
      "Em um Universo em expansão, o fator de escala aumenta e o comprimento de onda da radiação é esticado. Para uma fase dominada por radiação, a temperatura diminui aproximadamente como o inverso do fator de escala. A densidade de energia da radiação também cai mais rapidamente que a densidade de matéria não relativística.",
    detail:
      "A expansão não deve ser imaginada como matéria avançando para dentro de um espaço externo vazio. É a distância entre pontos comóveis do próprio espaço que aumenta. A cena amplia a distribuição visual para representar essa mudança de escala; ela não é um mapa literal de partículas reais.",
    progress: 0.25,
  },
  {
    id: "hadrons",
    number: "03",
    eyebrow: "CONSEQUÊNCIA · TRANSIÇÃO QUARK-HÁDRON",
    title: "Quarks passam a compor hádrons.",
    description:
      "À medida que o Universo esfria, ocorre a transição do plasma de quarks e glúons para a fase hadrônica. Quarks e glúons deixam de existir como constituintes livres em grandes distâncias e passam a ficar confinados em hádrons. Prótons e nêutrons são exemplos de hádrons formados por quarks.",
    detail:
      "A transição ocorre em torno de uma escala térmica da ordem de 150–160 MeV, com detalhes descritos pela cromodinâmica quântica. A cena agrupa pontos em conjuntos para comunicar a ideia de confinamento; não calcula a dinâmica da QCD nem representa colisões individuais.",
    progress: 0.75,
  },
];
