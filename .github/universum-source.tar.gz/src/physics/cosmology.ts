/**
 * Modelo didático simplificado para um trecho dominado por radiação.
 *
 * Não é um solver cosmológico completo. Usa:
 *   a(t) / a0 = sqrt(t / t0)
 *   T(t) / T0 = a0 / a(t)
 *   H(t) = 1 / (2t)
 *
 * A normalização de temperatura é uma referência ilustrativa, não um
 * conjunto de dados observacionais calibrado. O intervalo demonstrado
 * é 10^-6 a 10^-4 segundos após o início da faixa simulada.
 */

export interface CosmologyState {
  progress: number;
  timeSeconds: number;
  scaleFactor: number;
  temperatureKelvin: number;
  hubblePerSecond: number;
}

const START_TIME = 1e-6;
const END_TIME = 1e-4;
const REFERENCE_TEMPERATURE = 1e13;

const clamp01 = (value: number) => Math.min(1, Math.max(0, value));

export function calculateCosmology(progress: number): CosmologyState {
  const p = clamp01(progress);
  const timeSeconds = START_TIME * Math.pow(END_TIME / START_TIME, p);
  const scaleFactor = Math.sqrt(timeSeconds / START_TIME);
  const temperatureKelvin = REFERENCE_TEMPERATURE / scaleFactor;
  const hubblePerSecond = 1 / (2 * timeSeconds);

  return {
    progress: p,
    timeSeconds,
    scaleFactor,
    temperatureKelvin,
    hubblePerSecond,
  };
}

export function formatScientific(value: number, digits = 2): string {
  return value.toExponential(digits).replace("e", " × 10^");
}

export function getPhase(progress: number): {
  index: string;
  title: string;
  subtitle: string;
} {
  if (progress < 0.25) {
    return {
      index: "01",
      title: "Plasma primordial",
      subtitle: "Um estado extremamente quente e denso",
    };
  }
  if (progress < 0.745) {
    return {
      index: "02",
      title: "Expansão e resfriamento",
      subtitle: "O fator de escala aumenta; a temperatura diminui",
    };
  }
  return {
    index: "03",
    title: "Formação de hádrons",
    subtitle: "A matéria passa por uma transição de regime",
  };
}
