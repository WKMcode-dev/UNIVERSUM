# UNIVERSUM

Experiência narrativa e visual para investigar a evolução do Universo.

## Requisitos

- Node.js 20.19+ ou 22.12+
- npm

## Instalação

```bash
npm install
npm run dev
```

Abra o endereço local indicado pelo Vite.

## Scripts

```bash
npm run dev       # servidor de desenvolvimento
npm run typecheck # verificação TypeScript
npm run build     # build de produção
npm run preview   # prévia do build
```

## Estrutura

```text
src/
├── components/       # cena 3D, narrativa e modal científica
├── data/             # capítulos da experiência
├── physics/          # cálculos físicos isolados da interface
├── styles/           # estilos globais e responsividade
├── App.tsx
└── main.tsx
```

## Rolagem e transições — v0.1.2

A linha do tempo agora é medida pela própria coluna narrativa, do início ao fim dela. Isso mantém a mesma referência no desktop e no mobile, mesmo quando a cena fixa ocupa uma faixa menor da tela. A rolagem não usa mais um atraso de interpolação separado (`scrub` com duração), que fazia o texto avançar antes da cena.

Os marcos são sincronizados em uma única escala:

- `0–25%`: plasma primordial;
- `25–74,5%`: expansão e resfriamento;
- a partir de `74,5%`: entrada gradual na faixa térmica associada ao crossover quark-hádron;
- `75%`: o capítulo sobre hádrons passa a ser o capítulo ativo.

A cena mantém as mesmas partículas durante toda a sequência. O fator de expansão aumenta continuamente, a câmera recua com a distribuição e, perto do crossover, os pontos se agrupam gradualmente em regiões visuais. Não há troca de cena nem reposicionamento para um conjunto de alvos fixos no centro. A contração dos pontos é uma metáfora gráfica de agrupamento/confinamento, não uma simulação de QCD.

## Limites científicos

O motor usa uma aproximação de Universo dominado por radiação:

- `a(t) / a₀ = sqrt(t / t₀)`
- `T(t) / T₀ = a₀ / a(t)`
- `H(t) = 1 / (2t)`

O intervalo é de `10⁻⁶` a `10⁻⁴` segundos dentro do trecho demonstrado. A normalização de temperatura de `10¹³ K` em `10⁻⁶ s` é didática e não substitui uma tabela termodinâmica calibrada nem uma integração completa das equações de Friedmann.

A visualização de partículas é uma representação artística procedural. Ela não resolve numericamente a cromodinâmica quântica nem simula colisões reais. Os textos deixam essa distinção explícita.

## Próximas evoluções recomendadas

1. Adicionar testes unitários para `calculateCosmology`.
2. Substituir a normalização didática por uma parametrização documentada.
3. Implementar integração configurável das equações de Friedmann.
4. Separar a transição QGP-hádrons em um modelo térmico com parâmetros de referência.
5. Adicionar controles de pausa, velocidade e navegação temporal sincronizados com a cena.
6. Implementar acessibilidade completa e fallback 2D para dispositivos sem WebGL.


## Diretriz editorial

A interface prioriza explicações físicas diretas: condição inicial, processo,
consequência e limites do modelo. Evite chamadas promocionais ou frases vagas
de convite à exploração. Cada etapa deve explicar o fenômeno, indicar o que
muda e separar resultados calculados de representações conceituais.

## Alterações da v0.1.2

- Linha do tempo baseada na altura real da coluna narrativa; os capítulos e o painel físico compartilham o mesmo progresso.
- Removido o atraso de rolagem que deixava a cena atrás do texto.
- Câmera 3D agora recua efetivamente durante a expansão; antes, a distância era calculada, mas não aplicada à câmera.
- Distribuição de partículas preservada entre etapas: expansão espacial contínua e agrupamento progressivo apenas na faixa final.
- Mudança gradual de cor e desaparecimento do núcleo visual inicial.
- Altura dos capítulos mobile alinhada à mesma duração relativa da linha do tempo.

A transição hadrônica continua sendo uma representação conceitual. A normalização térmica é didática; o marco de 74,5% é uma correspondência aproximada dentro deste intervalo de tempo, não uma integração termodinâmica da QCD.
